"""Build a portable, dependency-free HTML preview from the editable source files."""
from pathlib import Path
import re, json
ROOT = Path(__file__).resolve().parent
paths = {
 'left':'<path d="M19 12H5m6-6-6 6 6 6"/>',
 'right':'<path d="M5 12h14m-6-6 6 6-6 6"/>',
 'up':'<path d="M12 19V5m-6 6 6-6 6 6"/>',
 'ne':'<path d="M6 18 18 6M6 6h12v12"/>',
 'play':'<path d="m8 5 11 7-11 7z"/>',
 'pause':'<path d="M8 5v14M16 5v14"/>',
 'reset':'<path d="M3 10a9 9 0 1 1 2 8M3 4v6h6"/>',
 'plus':'<path d="M12 5v14M5 12h14"/>',
 'close':'<path d="m6 6 12 12M6 18 18 6"/>',
 'check':'<path d="m5 12 4 4L19 6"/>',
 'info':'<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-9v.5"/>',
 'book':'<path d="M12 5v15M12 5C8 3 4 3 3 4v15c3-1 6-1 9 1 3-2 6-2 9-1V4c-3-1-6-1-9 1Z"/>',
 'sun':'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.4 1.4m11.2 11.2L19 19M5 19l1.4-1.4M17.6 6.4 19 5"/>',
 'moon':'<path d="M20.5 14A9 9 0 0 1 10 3a9 9 0 1 0 10.5 11Z"/>',
 'route':'<circle cx="5" cy="5" r="2"/><circle cx="19" cy="19" r="2"/><path d="M7 5h8a4 4 0 0 1 0 8H9a4 4 0 0 0 0 8h8"/>',
 'chip':'<rect x="5" y="5" width="14" height="14" rx="3"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 2v3m6-3v3M9 19v3m6-3v3M2 9h3m-3 6h3m14-6h3m-3 6h3"/>',
 'file':'<path d="M6 2h8l5 5v15H5V2h1Zm8 0v6h5M8 12h8M8 16h8"/>',
 'code':'<path d="m8 6-6 6 6 6m8-12 6 6-6 6m-3-15-2 18"/>'
}
icons={name:f'<svg width="{36 if name in ("chip","file") else 17}" height="{36 if name in ("chip","file") else 17}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">{p}</svg>' for name,p in paths.items()}
body=(ROOT/'src/page.html').read_text()
body=re.sub(r'@([a-z]+)@',lambda m:icons[m[1]],body)
css=(ROOT/'src/theme.css').read_text()+'\n'+(ROOT/'src/concept.css').read_text()
js='window.VP_ICONS='+json.dumps(icons,ensure_ascii=False)+';\n'+(ROOT/'src/lesson-core.js').read_text()+'\n'+(ROOT/'src/interaction.js').read_text()
html='<!doctype html>\n<html lang="zh-CN" data-theme="light" data-palette="moss" data-background="paper"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="color-scheme" content="light dark"><meta name="description" content="VibePolaris Harness 交互词条样板：区分模型、运行组织与工具，亲手推进一次完整任务。"><title>Harness 智能体运行框架 — VibePolaris Vibe指北</title><style>'+css+'</style></head><body>'+body+'<script>'+js+'</script></body></html>'
(ROOT/'harness-vibepolaris.html').write_text(html)
print('Built:',ROOT/'harness-vibepolaris.html',len(html.encode()),'bytes')
