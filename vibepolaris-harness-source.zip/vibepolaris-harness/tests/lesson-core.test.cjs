const test = require('node:test');
const assert = require('node:assert/strict');
const { createState, reduce, frame, phases, scenarios } = require('../src/lesson-core.js');
const at = (step, scenario = 'success') => frame(createState({ step, scenario }));

test('initial state has a task, but no file content or API calls', () => {
 const f=at(0); assert.equal(f.fileVisible,false); assert.equal(f.modelCalls,0); assert.equal(f.toolCalls,0); assert.equal(f.context.length,1);
});
test('model tool request is not execution or observation', () => {
 const f=at(2); assert.equal(f.toolExecuted,false); assert.equal(f.fileVisible,false); assert.equal(f.toolCalls,0); assert.equal(f.context.some(x=>x.role==='tool'),false);
});
test('dispatch can happen before the result is received', () => {
 const f=at(3); assert.equal(f.toolExecuted,true); assert.equal(f.toolCalls,1); assert.equal(f.fileVisible,false); assert.equal(f.context.some(x=>x.role==='tool'),false);
});
test('successful result appears only at observation step', () => {
 for(let i=0;i<4;i++) assert.equal(at(i).fileVisible,false);
 for(let i=4;i<7;i++) assert.equal(at(i).fileVisible,true);
 assert.match(at(4).context.find(x=>x.role==='tool').text,/写好 README/);
});
test('a second model call happens only after tool feedback', () => {
 assert.equal(at(4).modelCalls,1); assert.equal(at(5).modelCalls,2); assert.equal(at(6).modelCalls,2);
});
test('missing file keeps all contents hidden and asks for a path', () => {
 for(let i=0;i<7;i++) assert.equal(at(i,'missing').fileVisible,false);
 assert.match(at(4,'missing').context.find(x=>x.role==='tool').text,/FileNotFound/);
 assert.equal(at(6,'missing').status,'等待补充'); assert.equal(at(6,'missing').toolCalls,1);
});
test('a denied request never executes a file tool', () => {
 for(let i=0;i<7;i++) { const f=at(i,'denied'); assert.equal(f.toolExecuted,false); assert.equal(f.toolCalls,0); assert.equal(f.fileVisible,false); }
 assert.equal(at(6,'denied').status,'等待授权'); assert.match(at(4,'denied').context.find(x=>x.role==='tool').text,/PermissionDenied/);
});
test('all scenarios stop with supported and distinguishable outcomes', () => {
 assert.equal(at(6,'success').status,'已完成');
 assert.notEqual(at(6,'missing').status,at(6,'success').status);
 assert.notEqual(at(6,'denied').status,at(6,'success').status);
 for(const name of Object.keys(scenarios)) assert.equal(at(6,name).trace.length,7);
});
test('navigation clamps at valid bounds and manual actions pause', () => {
 assert.equal(reduce(createState(),{type:'previous'}).step,0);
 assert.equal(reduce(createState({step:6}),{type:'next'}).step,6);
 assert.equal(reduce(createState(),{type:'seek',step:55}).step,6);
 assert.equal(reduce(createState(),{type:'seek',step:-55}).step,0);
 assert.equal(reduce(createState({playing:true}),{type:'next'}).playing,false);
});
test('autoplay advances and stops at final state without cycling', () => {
 let s=reduce(createState(),{type:'play'}); assert.equal(s.playing,true);
 for(let i=0;i<6;i++)s=reduce(s,{type:'tick'});
 assert.equal(s.step,6); assert.equal(s.playing,false);
 assert.deepEqual(reduce(s,{type:'tick'}),s);
});
test('autoplay replay explicitly starts a new run', () => {
 const s=reduce(createState({step:6}),{type:'play'}); assert.equal(s.step,0); assert.equal(s.playing,true);
});
test('switching scenarios resets the experiment; invalid values are ignored', () => {
 const old=createState({step:5,playing:true}); const s=reduce(old,{type:'scenario',value:'denied'});
 assert.equal(s.step,0); assert.equal(s.playing,false); assert.equal(s.scenario,'denied');
 assert.equal(reduce(old,{type:'scenario',value:'unknown'}),old);
});
test('model-only mode has no autoplay and mode switch starts cleanly', () => {
 let s=reduce(createState({step:4}),{type:'mode',value:'model'});
 assert.equal(s.step,0); assert.equal(s.mode,'model'); assert.equal(reduce(s,{type:'play'}).playing,false);
 s=reduce(s,{type:'mode',value:'harness'}); assert.equal(s.step,0);
});
test('playback speed changes without altering the factual step', () => {
 let s=createState({step:2}); for(const speed of [1.5,2,1]) {s=reduce(s,{type:'speed'});assert.equal(s.speed,speed);assert.equal(s.step,2);}
});
test('every frame provides a full teaching label and chronological trace', () => {
 for(const scenario of Object.keys(scenarios))for(let step=0;step<7;step++){ const f=at(step,scenario); assert.equal(f.phase,phases[step]); assert.ok(f.title&&f.description&&f.insight); assert.equal(f.trace.length,step+1); }
});
test('public initialization normalizes malformed preview inputs', () => {
 const s=createState({step:2.5,scenario:'__proto__',mode:'unknown',speed:-2});
 assert.equal(s.step,2);assert.equal(s.scenario,'success');assert.equal(s.mode,'harness');assert.equal(s.speed,1);
 assert.equal(reduce(s,{type:'scenario',value:'__proto__'}),s);
 assert.equal(reduce(s,{type:'seek',step:4.9}).step,4);
 assert.doesNotThrow(()=>frame(s));
});
