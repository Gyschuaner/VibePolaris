from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root = Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1440, 'height': 1060}, device_scale_factor=1)
    errors=[]
    page.on('pageerror', lambda exc: errors.append(str(exc)))
    page.set_content((root/'harness-vibepolaris.html').read_text(), wait_until='load')
    page.wait_for_function('window.__ready===true')
    page.screenshot(path=str(root/'preview-initial.png'), full_page=False)
    page.evaluate('window.VPPreview.seek(4)')
    page.wait_for_timeout(1000)
    page.screenshot(path=str(root/'preview-desktop.png'), full_page=False)
    page.screenshot(path=str(root/'preview-full.png'), full_page=True)
    print('DESKTOP',json.dumps(page.evaluate('({width:innerWidth,scroll:document.documentElement.scrollWidth,state:VPPreview.getState()})'),ensure_ascii=False))
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(400)
    page.screenshot(path=str(root/'preview-mobile.png'),full_page=True)
    print('MOBILE',json.dumps(page.evaluate('({width:innerWidth,scroll:document.documentElement.scrollWidth})')))
    page.set_viewport_size({'width':1440,'height':1060})
    page.evaluate("document.documentElement.dataset.theme='dark'")
    page.wait_for_timeout(300)
    page.screenshot(path=str(root/'preview-dark.png'),full_page=False)
    print('ERRORS',errors)
    browser.close()
