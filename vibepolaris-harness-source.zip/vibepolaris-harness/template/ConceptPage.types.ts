/** Suggested framework-neutral content contract, not a replacement for the site's Term/Zod schema. */
export type ConceptSectionKind = 'intuition' | 'mechanism' | 'comparison' | 'example';
export interface ConceptSource { id: string; title: string; url: `https://${string}`; publisher: string }
export interface ConceptSection { id: string; kind: ConceptSectionKind; title: string; body: readonly string[]; sourceIds?: readonly string[] }
export interface RelatedConcept { label: string; explanation: string; href: `/terms/${string}` | `/terms?q=${string}` }
export interface KnowledgeQuestion { id: string; prompt: string; choices: readonly { label: string; explanation: string; correct: boolean }[] }
export interface ConceptPageDefinition {
  slug: string;
  name: string;
  chineseName: string;
  category: readonly string[];
  definition: string;
  scopeNote: string;
  learningGoal: string;
  /** Registry key. Each concept can supply its own diagram, reducer and observation types. */
  experiment: { componentKey: string; title: string; simulated: true; defaultPlayback: 'manual' };
  sections: readonly ConceptSection[];
  related: readonly RelatedConcept[];
  questions: readonly KnowledgeQuestion[];
  sources: readonly ConceptSource[];
}
