import type { ConceptPageDefinition } from './ConceptPage.types';
/** Reuse spec for a later React migration; current HTML is built from src/page.html. */
export const harnessDefinition = {
  slug: 'agent-harness', name: 'Harness', chineseName: '智能体运行框架',
  category: ['AI', 'Agent'],
  definition: '模型决定下一步，Harness 让这一步真正发生。',
  scopeNote: '这里讨论 Agent Harness，不是评测模型的 evaluation harness；具体能力随任务而异。',
  learningGoal: '区分模型提出请求、Harness 检查并调度、工具实际执行，以及结果进入下一次输入。',
  experiment: { componentKey: 'HarnessLesson', title: '让一个任务，真正跑起来', simulated: true, defaultPlayback: 'manual' },
  sections: [
    { id: 'why', kind: 'intuition', title: '从告诉你怎么做，到根据结果接着做', body: ['只有模型时，应用输入文字，得到一段回答。要让它与文件、工具或 CAD 环境交互，就需要外部程序组织实际执行和反馈。'], sourceIds: ['agents'] },
    { id: 'inside', kind: 'mechanism', title: '把 Harness 打开，里面各自负责什么？', body: ['准备上下文、检查并调度工具、维护反馈循环，以及记录任务状态和边界。并不是每个系统都必须一次具备所有组件。'], sourceIds: ['harness'] },
    { id: 'compare', kind: 'comparison', title: '相邻的词，不同的职责', body: ['模型做判断，工具做操作，Harness 组织运行。Agent 描述整体系统；MCP 是连接协议；Skill 提供可加载的任务知识。'], sourceIds: ['agents', 'mcp', 'skills'] },
    { id: 'practice', kind: 'example', title: '换到 CAD，仍然是这个关系', body: ['这是一个假设的 CAD 任务：模型提出下一步操作，Harness 检查并调度，CAD 工具执行，系统根据实际结果验证。模型说完成，不代表几何结果已经满足要求。'], sourceIds: ['long-running'] }
  ],
  related: [
    { label: '上下文', explanation: '模型这一次，究竟能看到哪些信息？', href: '/terms/context' },
    { label: '工具调用', explanation: '从结构化请求，到实际执行。', href: '/terms?q=工具调用' },
    { label: '智能体循环', explanation: '判断、行动、观察，为什么要循环？', href: '/terms?q=Agent+Loop' }
  ],
  questions: [
    { id: 'execution-boundary', prompt: '模型输出 read_file 后，真正读文件的是谁？', choices: [
      { label: '模型', explanation: '模型生成的是读取请求。', correct: false },
      { label: 'Harness', explanation: 'Harness 检查并调度请求。', correct: false },
      { label: '文件工具', explanation: '工具实现真正打开文件并返回结果。', correct: true }
    ] },
    { id: 'stop-versus-success', prompt: '文件不存在，模型请用户确认路径。这一轮是什么状态？', choices: [
      { label: '已完成', explanation: '回答了，不代表已经读到了文件。', correct: false },
      { label: '等待补充', explanation: '还需要有效路径，不能凭空生成正文。', correct: true },
      { label: '无条件重试', explanation: '应先根据错误判断下一步，而不是盲目重复。', correct: false }
    ] }
  ],
  sources: [
    { id: 'agents', title: 'Building effective agents', publisher: 'Anthropic', url: 'https://www.anthropic.com/engineering/building-effective-agents' },
    { id: 'harness', title: 'Deep Agents overview', publisher: 'LangChain', url: 'https://docs.langchain.com/oss/python/deepagents/overview' },
    { id: 'mcp', title: 'MCP Architecture', publisher: 'Model Context Protocol', url: 'https://modelcontextprotocol.io/docs/learn/architecture' },
    { id: 'skills', title: 'Agent Skills', publisher: 'Agent Skills', url: 'https://agentskills.io/home' },
    { id: 'long-running', title: 'Effective harnesses for long-running agents', publisher: 'Anthropic', url: 'https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents' }
  ]
} as const satisfies ConceptPageDefinition;
