/* Preview UI: zero dependencies; all simulation values originate in lesson-core.js.
   Own all listeners/timers so this controller can also be mounted from a React effect. */
(function () {
  'use strict';
  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));
  const core = window.VPHarness;
  if (!core) throw new Error('VPHarness lesson-core.js must be loaded first.');
  const controller = new AbortController();
  const on = (el, type, fn, options = {}) => el && el.addEventListener(type, fn, { ...options, signal: controller.signal });
  const escape = (s) => String(s).replace(/[&<>"']/g, x => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[x]);
  const reduced = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
  let state = core.createState(), inspectorTab = 'explanation', timer = 0, flowRaf = 0, toastTimer = 0;
  let prevStep = -1, prevScenario = '', quizIndex = 0;
  const quizAnswers = [null, null];
  const icons = window.VP_ICONS;
  const glossary = {
    model: { name: 'Model · 模型', en: 'THE DECISION MAKER', text: '模型根据这一次收到的上下文，生成回答或工具请求。它不会因为写下 read_file，就自动在你的电脑上打开文件。', extra: '在实验第 3 步，模型只是提出了请求。工具要到后面才可能执行。', href: '/terms?q=LLM' },
    harness: { name: 'Harness · 运行组织', en: 'THE RUNTIME AROUND THE MODEL', text: '这里的 Harness，是围绕模型工作的程序层。它把任务与可用工具说明准备好，处理模型的请求，把结果送回去，并管理状态、边界和停止条件。', extra: '它不是另一位更聪明的模型，也不是某个工具的别名。具体功能可以按任务取舍。', href: '/terms/agent-harness' },
    tool: { name: 'Tool · 工具', en: 'THE ACTUAL EXECUTOR', text: '工具是可调用的实际能力，例如读取文件、运行命令或查询 CAD 对象。Harness 负责把合法请求交给它，工具实现真正执行操作并返回结果。', extra: 'read_file("todo.txt") 是请求；文件读取函数实际返回的内容或错误，才是执行结果。', href: '/terms?q=工具调用' },
    agent: { name: 'Agent · 智能体', en: 'THE WHOLE WORKING SYSTEM', text: 'Agent 通常指围绕模型构建、能够与工具和环境交互并推进任务的整体系统。模型产生判断，外部程序支撑行动、反馈与运行控制。', extra: '“Agent ≈ 模型 + Harness”是一种入门比喻。它不是所有文献统一采用的严格定义。', href: '/terms/agent' },
    mcp: { name: 'MCP · 连接协议', en: 'MODEL CONTEXT PROTOCOL', text: 'MCP 约定应用与外部服务交换工具、资源、提示模板等信息的方式。应用可以借助 MCP 接入能力，但如何规划任务、管理上下文和循环，仍由应用自己组织。', extra: '没有 MCP 也能做 Harness；使用 MCP 也不自动等于拥有完整的 Agent。', href: '/terms?q=MCP' },
    skill: { name: 'Skill · 可加载的技能包', en: 'REUSABLE TASK KNOW-HOW', text: 'Skill 可以把某类任务的操作说明、参考资料和可选脚本打包，让智能体需要时再加载。你前面指定的设计 skill，正是在提供这类任务知识。', extra: 'Skill 指导怎么做，工具实际去做，Harness 组织它们如何运行。', href: '/terms?q=Skill' },
    context: { name: 'Context · 上下文', en: 'WHAT THE MODEL CAN SEE NOW', text: '上下文是模型本次调用能够接收到的信息：任务、规则、工具说明，以及被加入输入的历史和工具结果。没有被放进输入的文件内容，不会因为文件名出现了就自动被模型知道。', extra: '它是“当前工作台”，不等同于“永久记忆”。长期保存的信息也需要被选取后加入输入，才能在当前调用中起作用。', href: '/terms/context' },
    loop: { name: 'Agent Loop · 智能体循环', en: 'DECIDE → ACT → OBSERVE', text: '调用模型，处理它提出的工具请求，收集实际结果，再把这些结果交给模型判断。只要任务还需要行动，就继续；输出最终回答、等待输入、被取消或达到预算时，可以结束本轮。', extra: '循环不是“永远重试”。错误、权限和任务标准都会影响下一步。', href: '/terms?q=Agent+Loop' }
  };
  const parts = {
    context: { en: 'CONTEXT / INPUT', title: '给模型一张准确的工作台。', text: '准备任务、规则、工具说明，以及已经得到的结果。每一次调用，模型只能利用实际进入这次输入的信息。不是把所有文件都塞进去，也不是默认记得上一轮。', example: '第一次：任务 + 工具说明\n第二次：之前的输入 + 请求 + 工具结果' },
    tools: { en: 'TOOLS / DISPATCH', title: '把“想做”接到“能做”。', text: '解析工具名与参数，检查调用是否允许，再交给对应工具。执行失败就返回错误，执行超时就结束等待，而不是把一次请求当作已经完成。', example: '请求：read_file("todo.txt")\n检查：工具存在 / 参数正确 / 路径获准\n执行：工具返回正文，或返回错误' },
    loop: { en: 'LOOP / FEEDBACK', title: '让下一步依赖真实反馈。', text: '模型给出请求，工具返回结果，Harness 再次调用模型。工具报错后，模型可以换个做法或询问用户。循环的意义是让新结果影响下一步，而不是机械重复。', example: '模型 → 工具请求 → 实际结果 → 模型\n              ↘ 最终回答 / 等待输入 / 停止' },
    control: { en: 'CONTROL / STATE', title: '记住进度，也守住边界。', text: '记录当前任务做到了哪里，规定可以访问什么，并设置时间、轮数或费用限制。中断后从可核对的状态恢复；有删除或覆盖风险时，可以要求人工确认。', example: '允许：读取工作目录内的文件\n受限：删除文件前等待确认\n停止：完成 / 取消 / 超时 / 达到预算' }
  };
  const quiz = [
    { question: '模型输出了 read_file("todo.txt")。真正读取文件的是谁？', options: [['模型', '产生请求'], ['Harness', '检查并调度'], ['文件工具', '执行具体操作']], correct: 2, explanations: ['模型输出的是读取请求，还没有发生文件操作。真正读取由文件工具实现完成。', 'Harness 负责解析、检查并调度请求。在我们区分的这三个角色里，真正打开文件的是工具。', '对。工具真正读取；模型提出请求；Harness 把请求、执行和结果组织起来。'] },
    { question: '工具返回 FileNotFound，模型请用户确认路径。这轮任务是什么状态？', options: [['已完成', '已经生成一段回答'], ['等待补充', '还缺少有效路径'], ['继续读到成功', '可以忽略错误']], correct: 1, explanations: ['生成了回答，不代表读到了文件。目标还没有达成，这里是在等待用户补充有效路径。', '对。它诚实地保留错误并请求补充。停止了这一轮，但没有把“失败”标成“完成”。', '不能忽略错误。路径不存在时盲目重试没有依据，应该查找原因、换方法或请求用户补充。'] }
  ];

  function dispatch(action) {
    state = core.reduce(state, action);
    render();
    return state;
  }
  function renderInspector() {
    const panel = $('#inspector-body'), f = core.frame(state);
    panel.dataset.tab = inspectorTab;
    panel.setAttribute('aria-labelledby', 'tab-' + inspectorTab);
    let html = '';
    if (state.mode === 'model') {
      html = '<div class="vp-inspector-step">MODEL ONLY</div><h3>此时，它还不能读文件。</h3><p>这次输入只有任务和文件名，没有正文，也没有开放工具。模型可以请你粘贴文件内容，但不能凭空知道待办。</p><div class="vp-insight">' + icons.info + '<span>区别在于本例提供的能力，不是模型被换成了“更笨的版本”。</span></div>';
    } else if (inspectorTab === 'context') {
      html = f.context.map(row => '<div class="vp-context-row"><span>' + escape(row.role) + '</span><div>' + escape(row.text) + '</div></div>').join('') + '<p class="vp-context-footnote">展示本轮已准备的输入记录；只有下一次调用时实际发送的内容，才进入模型上下文。此处省略了协议字段。</p>';
    } else if (inspectorTab === 'trace') {
      html = f.trace.map((row, i) => '<div class="vp-trace-row"><span>' + String(i + 1).padStart(2, '0') + '</span><div><strong>' + escape(row.who) + '</strong><p>' + escape(row.what) + '</p><code>' + escape(row.value) + '</code></div></div>').join('');
    } else {
      html = '<div class="vp-inspector-step">STEP ' + String(state.step + 1).padStart(2, '0') + ' / 07</div><h3>' + escape(f.title) + '</h3><p>' + escape(f.description) + '</p><div class="vp-insight">' + icons.info + '<span>' + escape(f.insight) + '</span></div>';
    }
    panel.innerHTML = html;
    panel.scrollTop = 0;
    panel.classList.remove('is-changing');
    if (!reduced()) { void panel.offsetWidth; panel.classList.add('is-changing'); }
  }
  function drawEdges() {
    const graph = $('#graph'), bounds = graph.getBoundingClientRect();
    const get = (id) => {
      const b = $('#actor-' + id).getBoundingClientRect();
      return { left: b.left - bounds.left, right: b.right - bounds.left, y: b.top - bounds.top + b.height / 2 };
    };
    const m = get('model'), h = get('harness'), t = get('tool');
    const gap = bounds.width < 400 ? 2 : 5, delta = bounds.width < 400 ? 12 : 20;
    const edges = {
      hm: [h.left - gap, h.y - delta, m.right + gap, m.y - delta],
      mh: [m.right + gap, m.y + delta, h.left - gap, h.y + delta],
      ht: [h.right + gap, h.y - delta, t.left - gap, t.y - delta],
      th: [t.left - gap, t.y + delta, h.right + gap, h.y + delta]
    };
    const f = core.frame(state);
    for (const [key, [x1,y1,x2,y2]] of Object.entries(edges)) {
      const p = $('#edge-' + key), mid = (x1 + x2) / 2;
      p.setAttribute('d', `M ${x1} ${y1} C ${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}`);
      const active = state.mode === 'harness' && f.edge === key;
      p.dataset.active = String(active);
      p.setAttribute('marker-end', `url(#arrow-${active ? 'active' : 'normal'})`);
    }
  }
  function flow() {
    cancelAnimationFrame(flowRaf);
    const dot = $('#flow-dot'), f = core.frame(state), p = f.edge && $('#edge-' + f.edge);
    dot.classList.remove('active');
    if (state.mode !== 'harness' || reduced() || !p || document.hidden) return;
    const len = p.getTotalLength(), start = performance.now();
    dot.classList.add('active');
    const tick = (now) => {
      const progress = Math.min(1, (now - start) / 900);
      const point = p.getPointAtLength(len * progress);
      dot.setAttribute('cx', point.x); dot.setAttribute('cy', point.y);
      if (progress < 1) flowRaf = requestAnimationFrame(tick);
      else dot.classList.remove('active');
    };
    flowRaf = requestAnimationFrame(tick);
  }
  function render() {
    clearTimeout(timer);
    const f = core.frame(state), modelOnly = state.mode === 'model';
    $('#graph').dataset.step = String(state.step); $('#graph').dataset.mode = state.mode;
    $('#model-text').textContent = modelOnly ? '请提供文件正文，\n我才能整理未完成项。' : f.modelText;
    $('#runtime-text').textContent = modelOnly ? '没有接入运行组织' : f.runtimeText;
    $('#tool-text').textContent = modelOnly ? '没有向模型开放' : f.toolText;
    $('#file-content').hidden = modelOnly || !f.fileVisible;
    $('#file-placeholder').hidden = !modelOnly && f.fileVisible;
    $('#file-icon').hidden = !modelOnly && f.fileVisible;
    for (const name of ['model','harness','tool']) $('#actor-' + name).dataset.active = String(modelOnly ? name === 'model' : f.active === name);
    const activeRow = state.step < 2 ? 'context' : state.step < 4 ? 'dispatch' : 'loop';
    $$('[data-runtime-row]').forEach(el => el.classList.toggle('is-active', !modelOnly && el.dataset.runtimeRow === activeRow));
    $$('[data-lesson-mode]').forEach(el => el.setAttribute('aria-pressed', String(el.dataset.lessonMode === state.mode)));
    $$('[data-step-button]').forEach((el, i) => {
      if (i === state.step && !modelOnly) el.setAttribute('aria-current','step'); else el.removeAttribute('aria-current');
      el.classList.toggle('done', i < state.step && !modelOnly); el.disabled = modelOnly;
    });
    $('#step-current').textContent = modelOnly ? '—' : String(state.step + 1).padStart(2, '0');
    $('#model-calls').textContent = modelOnly ? '1' : String(f.modelCalls);
    $('#tool-calls').textContent = modelOnly ? '0' : String(f.toolCalls);
    $('#sim-status').textContent = modelOnly ? '等待正文' : f.status;
    $('#previous').disabled = modelOnly || state.step === 0;
    $('#next').disabled = modelOnly;
    $('#next').innerHTML = state.step === 6 ? '重新开始 ' + icons.reset : '下一步 ' + icons.right;
    $('#play').disabled = modelOnly;
    $('#play').innerHTML = (state.playing ? icons.pause : icons.play) + '<span>' + (state.playing ? '暂停播放' : '自动播放') + '</span>';
    $('#play').setAttribute('aria-label', state.playing ? '暂停演示' : '自动播放演示');
    $('#speed').textContent = state.speed + '×'; $('#speed').setAttribute('aria-label', '播放速度，当前 ' + state.speed + ' 倍');
    $('#scenario').disabled = modelOnly; $('#scenario').value = state.scenario;
    $('#play-status').textContent = state.playing ? '正在自动播放' : state.step === 6 && !modelOnly ? '本轮演示已停止' : '由你掌握节奏';
    $('#play-dot').classList.toggle('stopped', !state.playing);
    $('#lesson-status').textContent = modelOnly ? '只用模型：没有文件正文，也没有文件工具。' : `第 ${state.step + 1} 步，${f.title}。${f.insight}`;
    const changed = prevStep !== state.step || prevScenario !== state.scenario;
    renderInspector(); drawEdges();
    if (changed) flow();
    if (!state.playing && !changed) { cancelAnimationFrame(flowRaf); $('#flow-dot').classList.remove('active'); }
    prevStep = state.step; prevScenario = state.scenario;
    if (state.playing && !document.hidden) timer = setTimeout(() => dispatch({ type:'tick' }), 3200 / state.speed);
  }

  $('#phase-rail').innerHTML = core.phases.map((name, i) => '<button type="button" data-step-button="' + i + '" aria-label="第 ' + (i + 1) + ' 步：' + name + '"><span>' + String(i + 1).padStart(2, '0') + '</span>' + name + '</button>').join('');
  $$('[data-step-button]').forEach(el => on(el,'click',() => dispatch({ type:'seek', step:Number(el.dataset.stepButton) })));
  on($('#next'),'click',() => dispatch({type:state.step === 6 ? 'reset' : 'next'}));
  on($('#previous'),'click',() => dispatch({type:'previous'}));
  on($('#reset'),'click',() => dispatch({type:'reset'}));
  on($('#play'),'click',() => dispatch({type:'play'}));
  on($('#speed'),'click',() => dispatch({type:'speed'}));
  on($('#scenario'),'change',e => dispatch({type:'scenario',value:e.target.value}));
  $$('[data-lesson-mode]').forEach(el => on(el,'click',() => dispatch({type:'mode', value:el.dataset.lessonMode})));
  on($('#harness-demo'),'keydown',e => {
    if (e.altKey || e.metaKey || e.ctrlKey || state.mode === 'model' || e.target.closest('[role="tablist"]') || ['SELECT','INPUT','TEXTAREA'].includes(e.target.tagName)) return;
    if (e.key === 'ArrowRight') { e.preventDefault(); dispatch({type:'next'}); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); dispatch({type:'previous'}); }
    if (e.key === ' ' && !e.target.closest('button,a')) { e.preventDefault(); dispatch({type:'play'}); }
  });
  function useTabs(selector, change, vertical = false) {
    const tabs = $$(selector);
    const select = (el) => { tabs.forEach(t => { t.setAttribute('aria-selected', String(t === el)); t.tabIndex = t === el ? 0 : -1; }); change(el); };
    tabs.forEach((el, i) => {
      on(el,'click',() => select(el));
      on(el,'keydown',e => {
        const prev = vertical ? 'ArrowUp' : 'ArrowLeft', next = vertical ? 'ArrowDown' : 'ArrowRight';
        if (![prev,next,'Home','End'].includes(e.key)) return;
        e.preventDefault(); e.stopPropagation();
        const j = e.key === 'Home' ? 0 : e.key === 'End' ? tabs.length - 1 : (i + (e.key === prev ? -1 : 1) + tabs.length) % tabs.length;
        select(tabs[j]); tabs[j].focus();
      });
    });
  }
  useTabs('[data-inspect]', el => { inspectorTab = el.dataset.inspect; renderInspector(); });
  function renderPart(key) {
    const p = parts[key];
    $('#part-panel').setAttribute('aria-labelledby', 'part-' + key);
    $('#part-panel').innerHTML = '<div class="vp-part-en">' + p.en + '</div><h3>' + p.title + '</h3><p>' + p.text + '</p><div class="vp-part-example">' + escape(p.example) + '</div>';
  }
  useTabs('[data-part]', el => renderPart(el.dataset.part), true); renderPart('context');

  const dialog = $('#glossary-dialog');
  $$('[data-glossary]').forEach(el => on(el,'click',() => {
    if (state.playing) dispatch({type:'pause'});
    const g = glossary[el.dataset.glossary];
    $('#glossary-title').textContent = g.name; $('#glossary-label').textContent = g.en;
    $('#glossary-description').textContent = g.text; $('#glossary-extra').textContent = g.extra;
    $('#glossary-link').href = 'https://vibepolaris.com' + g.href;
    dialog.showModal();
  }));
  on($('#close-dialog'),'click',() => dialog.close());
  on(dialog,'click',e => { if (e.target !== dialog) return; const b = dialog.getBoundingClientRect(); if (e.clientX < b.left || e.clientX > b.right || e.clientY < b.top || e.clientY > b.bottom) dialog.close(); });

  function renderQuiz() {
    const q = quiz[quizIndex], selected = quizAnswers[quizIndex];
    $('#quiz-question').textContent = q.question;
    $('#quiz-options').innerHTML = q.options.map(([name,note], i) => '<button type="button" class="vp-quiz-option' + (selected === i && i === q.correct ? ' correct' : '') + '" data-answer="' + i + '" aria-pressed="' + (selected === i) + '"><span>' + 'ABC'[i] + '</span><span><strong>' + name + '</strong><small>' + note + '</small></span></button>').join('');
    $$('#quiz-options [data-answer]').forEach(el => on(el,'click',() => { quizAnswers[quizIndex] = Number(el.dataset.answer); renderQuiz(); $('#quiz-options [data-answer="' + quizAnswers[quizIndex] + '"]').focus({preventScroll:true}); }));
    $('#quiz-answer').textContent = selected === null ? '选择一个答案，看看各自的职责。' : q.explanations[selected];
    $('#quiz-answer').dataset.correct = String(selected === q.correct);
    $('#quiz-next').disabled = selected !== q.correct;
    $('#quiz-next').innerHTML = quizIndex === 0 ? '下一题 ' + icons.right : '完成小测试 ' + icons.check;
    $('#quiz-progress').textContent = '问题 ' + String(quizIndex + 1).padStart(2,'0') + ' / 02';
  }
  on($('#quiz-next'),'click',() => {
    if (quizAnswers[quizIndex] !== quiz[quizIndex].correct) return;
    if (quizIndex === 0) { quizIndex = 1; renderQuiz(); $('#quiz-question').tabIndex=-1; $('#quiz-question').focus({preventScroll:true}); }
    else { $('#quiz-complete').hidden=false; $('#quiz-next').disabled=true; $('#quiz-next').textContent='已完成'; }
  }); renderQuiz();
  function toast(text) { clearTimeout(toastTimer); $('#toast').textContent=text; $('#toast').hidden=false; toastTimer=setTimeout(() => { $('#toast').hidden=true; },2400); }
  on($('#copy-code'),'click',async () => {
    const text = $('#loop-code').innerText;
    try { await navigator.clipboard.writeText(text); toast('伪代码已复制。'); }
    catch (_) {
      const area=document.createElement('textarea'); area.value=text; area.style.cssText='position:fixed;top:0;left:0;opacity:0'; document.body.appendChild(area);area.select();
      const ok=document.execCommand('copy'); area.remove();
      if (ok) toast('伪代码已复制。'); else { const range=document.createRange();range.selectNodeContents($('#loop-code'));getSelection().removeAllRanges();getSelection().addRange(range);toast('请使用键盘复制已选中的代码。'); }
    }
  });

  function store(key, value) { try { localStorage.setItem(key,value); } catch (_) {} }
  function load(key) { try { return localStorage.getItem(key); } catch (_) { return null; } }
  function themeUpdate(key,value) { document.documentElement.dataset[key]=value;store('vp-'+(key === 'theme' ? 'theme' : key),value); syncTheme(); }
  function syncTheme() {
    const data=document.documentElement.dataset;
    $$('#theme-panel [data-mode]').forEach(el => el.setAttribute('aria-pressed',String(el.dataset.mode === data.theme)));
    $$('#theme-panel [data-background]').forEach(el => el.setAttribute('aria-pressed',String(el.dataset.background === data.background)));
    $$('#theme-panel [data-palette]').forEach(el => el.setAttribute('aria-pressed',String(el.dataset.palette === data.palette)));
    $('#theme-toggle').innerHTML = data.theme === 'dark' ? icons.moon : icons.sun;
  }
  const params = new URLSearchParams(location.search), presets = { theme:['light','dark'], palette:['moss','indigo','clay','pine','plum'], background:['paper','oat','limestone','pearl','mist'] };
  for (const [key,values] of Object.entries(presets)) {
    const current = params.get(key) || load('vp-'+key);
    if (values.includes(current)) document.documentElement.dataset[key]=current;
  }
  syncTheme();
  function closeTheme() { $('#theme-panel').hidden=true;$('#theme-toggle').setAttribute('aria-expanded','false'); }
  on($('#theme-toggle'),'click',() => { const open=$('#theme-panel').hidden;$('#theme-panel').hidden=!open;$('#theme-toggle').setAttribute('aria-expanded',String(open)); });
  $$('#theme-panel [data-mode]').forEach(el => on(el,'click',() => themeUpdate('theme',el.dataset.mode)));
  $$('#theme-panel [data-background]').forEach(el => on(el,'click',() => themeUpdate('background',el.dataset.background)));
  $$('#theme-panel [data-palette]').forEach(el => on(el,'click',() => themeUpdate('palette',el.dataset.palette)));
  on(document,'pointerdown',e => { if (!e.target.closest('.vp-theme-wrap')) closeTheme(); });
  on(document,'keydown',e => { if (e.key === 'Escape' && !$('#theme-panel').hidden) { closeTheme(); $('#theme-toggle').focus(); } });

  $$('a[href^="#"]').forEach(el => on(el,'click',e => {
    const target = document.getElementById(el.getAttribute('href').slice(1)); if (!target) return;
    e.preventDefault();
    if (target.closest('details')) target.closest('details').open = true;
    const y = target.getBoundingClientRect().top + window.scrollY - (el.classList.contains('vp-source-inline') ? 150 : target.id === 'harness-demo' ? 86 : 137);
    window.scrollTo({top:Math.max(0,y),behavior:reduced() ? 'auto' : 'smooth'});
    if (target.id === 'top') window.scrollTo({top:0,behavior:reduced()?'auto':'smooth'});
    if (target.id === 'main-content') { target.tabIndex=-1;target.focus({preventScroll:true}); }
  }));
  let scrollRaf = 0;
  const updateToc = () => {
    scrollRaf=0; const sections=['why','inside','compare','practice','check']; let active=sections[0];
    sections.forEach(id => { if ($('#'+id).getBoundingClientRect().top <= 210) active=id; });
    $$('[data-section]').forEach(el => { const chosen=el.dataset.section===active;el.classList.toggle('active',chosen);if(chosen)el.setAttribute('aria-current','location');else el.removeAttribute('aria-current'); });
  };
  on(window,'scroll',() => { if (!scrollRaf) scrollRaf=requestAnimationFrame(updateToc); },{passive:true});
  const ro=new ResizeObserver(() => drawEdges());ro.observe($('#graph'));$$('.vp-actor').forEach(el => ro.observe(el));
  const io=new IntersectionObserver(entries => { if (entries[0].intersectionRatio < .15 && state.playing) dispatch({type:'pause'}); },{threshold:.15});io.observe($('#harness-demo'));
  on(document,'visibilitychange',() => { if (document.hidden && state.playing) dispatch({type:'pause'}); });
  const media=matchMedia('(prefers-reduced-motion: reduce)');on(media,'change',() => { cancelAnimationFrame(flowRaf);$('#flow-dot').classList.remove('active'); });
  render(); updateToc();
  window.__ready=true;
  window.VPPreview={
    getState:() => ({...state}),
    seek:(step,scenario) => { if(scenario)state=core.reduce(state,{type:'scenario',value:scenario});return dispatch({type:'seek',step}); },
    dispatch,
    destroy:() => {controller.abort();clearTimeout(timer);clearTimeout(toastTimer);cancelAnimationFrame(flowRaf);cancelAnimationFrame(scrollRaf);ro.disconnect();io.disconnect();}
  };
})();
