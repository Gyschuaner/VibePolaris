/* Pure, deterministic teaching model. No model API, filesystem or CAD access. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.VPHarness = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const task = '看看 todo.txt，还有哪些事没做？';
  const todos = [
    { text: '整理项目文件', done: true },
    { text: '写好 README', done: false },
    { text: '补充运行测试', done: false }
  ];
  const phases = ['接收任务', '准备输入', '提出请求', '检查与执行', '收回结果', '再次判断', '结束本轮'];
  const scenarios = {
    success: { label: '顺利读取', result: '[x] 整理项目文件\n[ ] 写好 README\n[ ] 补充运行测试', final: '还有两件事：写好 README、补充运行测试。', status: '已完成', outcome: '有结果，也有依据。回答来自工具返回的文件内容。' },
    missing: { label: '文件不存在', result: 'FileNotFound: todo.txt', final: '没有找到 todo.txt。请确认文件名，或提供正确路径。', status: '等待补充', outcome: '停止不等于成功。这一轮需要用户补充路径，不能编造文件内容。' },
    denied: { label: '无读取权限', result: 'PermissionDenied: 路径不在允许范围', final: '目前没有读取权限。请授权可访问的路径，或直接提供文件内容。', status: '等待授权', outcome: '提出请求不等于获准执行。工具没有运行，模型只能看到拒绝结果。' }
  };
  const clampStep = (step) => Math.max(0, Math.min(6, Math.trunc(Number(step) || 0)));
  const validScenario = (value) => Object.prototype.hasOwnProperty.call(scenarios, value);
  function createState(options) {
    const o = options && typeof options === 'object' ? options : {};
    const mode = o.mode === 'model' ? 'model' : 'harness';
    return { step: clampStep(o.step), scenario: validScenario(o.scenario) ? o.scenario : 'success',
      mode, playing: mode === 'harness' && o.playing === true, speed: [1,1.5,2].includes(o.speed) ? o.speed : 1 };
  }
  function reduce(state, action) {
    switch (action.type) {
      case 'next': return { ...state, step: Math.min(6, state.step + 1), playing: false };
      case 'previous': return { ...state, step: Math.max(0, state.step - 1), playing: false };
      case 'seek': return { ...state, step: clampStep(action.step), playing: false };
      case 'reset': return { ...state, step: 0, playing: false };
      case 'scenario': return validScenario(action.value) ? { ...state, step: 0, playing: false, scenario: action.value } : state;
      case 'mode': return ['harness', 'model'].includes(action.value) ? { ...state, step: 0, playing: false, mode: action.value } : state;
      case 'play': return state.mode === 'model' ? state : { ...state, step: state.step === 6 ? 0 : state.step, playing: !state.playing };
      case 'pause': return { ...state, playing: false };
      case 'tick': return !state.playing ? state : { ...state, step: Math.min(6, state.step + 1), playing: state.step < 5 };
      case 'speed': return { ...state, speed: state.speed === 1 ? 1.5 : state.speed === 1.5 ? 2 : 1 };
      default: return state;
    }
  }
  function frame(state) {
    const s = state.step, variant = scenarios[state.scenario], denied = state.scenario === 'denied', missing = state.scenario === 'missing';
    const annotations = [
      ['先收到任务', '你只给了一个文件名，还没有把文件正文交给模型。Harness 先接住任务，并保留本轮状态。', '文件正文尚未进入上下文'],
      ['把模型需要的信息备齐', 'Harness 把用户任务和 read_file 工具说明组成输入，然后发起第一次模型调用。此时模型知道有这个工具，但还不知道文件里写了什么。', '模型调用 01 · 任务 + 工具说明'],
      ['模型提出工具请求', '模型输出 read_file("todo.txt")。这是一条结构化请求，不是已经读到了文件；它需要交给外部程序处理。', '请求 ≠ 执行 ≠ 结果'],
      denied ? ['先检查，再决定是否执行', 'Harness 发现这条路径没有读取权限，于是阻止调度。文件工具根本没有运行，模型的请求不能越过权限边界。', '检查未通过 · 工具执行 0 次'] : ['Harness 检查，工具执行', 'Harness 检查工具名、参数和允许访问的路径，随后调度文件工具。真正打开文件的是工具实现，而不是模型生成的文字。', '通过权限检查 · 正在等待工具返回'],
      denied ? ['拒绝结果也要交回去', 'Harness 生成 PermissionDenied 结果，把拒绝原因放入下一轮上下文。没有文件正文，也不能假装读取成功。', '新增上下文 · 权限错误'] : missing ? ['错误也是一种结果', '文件工具实际返回 FileNotFound。Harness 保留这个错误并交回模型，让下一步根据真实结果继续，而不是把失败当成功。', '新增上下文 · 文件未找到'] : ['把真实结果放回上下文', '工具返回了三条待办。Harness 把这份结果和之前的工具请求一起放回上下文，下一次模型调用才能用到它。', '新增上下文 · 文件正文'],
      ['让模型根据结果再次判断', denied ? '第二次调用中，模型看到的是权限错误。因此它可以请求授权或请你粘贴正文，不能宣称知道哪些待办未完成。' : missing ? '第二次调用中，模型看到文件未找到的错误。因此它请求你确认路径，而不是继续凭空生成待办。' : '第二次调用中，模型终于看到了文件正文。它区分已完成和未完成的项目，再组织回答。需要更多信息时，也可以提出新的工具请求。', '模型调用 02 · 已包含工具结果'],
      ['这一轮，在这里停下', variant.outcome + ' 真实系统也可以因达到步数、时间或费用限制而停止。', variant.status + ' · 不再自动调用模型']
    ];
    const trace = [
      { who: 'Harness', what: '接收用户任务', value: task },
      { who: 'Harness → Model', what: '第一次调用', value: 'user + tool schema' },
      { who: 'Model → Harness', what: '提出请求', value: 'read_file({path: "todo.txt"})' },
      denied ? { who: 'Harness', what: '阻止工具调用', value: 'permission check: denied' } : { who: 'Harness → Tool', what: '通过检查，执行读取', value: 'permission check: allowed' },
      { who: denied ? 'Harness' : 'Tool → Harness', what: denied ? '记录拒绝结果' : missing ? '返回错误' : '返回文件正文', value: variant.result },
      { who: 'Harness → Model', what: '第二次调用', value: 'history + tool result' },
      { who: 'Model → User', what: variant.status, value: variant.final }
    ].slice(0, s + 1);
    const context = [
      { role: 'user', text: task },
      ...(s >= 1 ? [{ role: 'tools', text: 'read_file(path: string) → 文件正文或错误' }] : []),
      ...(s >= 2 ? [{ role: 'assistant', text: '工具请求：read_file({path: "todo.txt"})' }] : []),
      ...(s >= 4 ? [{ role: 'tool', text: variant.result }] : []),
      ...(s >= 6 ? [{ role: 'assistant', text: variant.final }] : [])
    ];
    return {
      title: annotations[s][0], description: annotations[s][1], insight: annotations[s][2],
      phase: phases[s], active: s === 1 || s === 2 || s === 5 ? 'model' : s === 3 && !denied ? 'tool' : 'harness',
      edge: s === 1 || s === 5 ? 'hm' : s === 2 || s === 6 ? 'mh' : s === 3 && !denied ? 'ht' : s === 4 && !denied ? 'th' : null,
      fileVisible: state.scenario === 'success' && s >= 4,
      toolExecuted: !denied && s >= 3, modelCalls: s >= 5 ? 2 : s >= 1 ? 1 : 0,
      toolCalls: !denied && s >= 3 ? 1 : 0,
      modelText: s < 1 ? '等待输入' : s === 1 ? '了解任务与可用工具' : s < 5 ? 'read_file\n("todo.txt")' : s === 5 ? '结合工具结果判断' : variant.final,
      runtimeText: ['保存本轮任务', '准备模型输入', '接住工具请求', denied ? '权限检查未通过' : '检查通过，调度工具', '记录工具返回值', '带着结果再次调用', variant.status][s],
      toolText: s < 3 ? '尚未执行' : denied ? '没有获得执行许可' : s === 3 ? '读取演示文件…' : missing ? 'FileNotFound' : '已返回 3 条待办',
      trace, context, outcome: variant.final, status: s === 6 ? variant.status : denied && s >= 3 ? '请求被阻止' : '教学模拟',
      denied, missing
    };
  }
  return { task, todos, phases, scenarios, createState, reduce, frame };
});
