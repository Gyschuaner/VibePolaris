# VibePolaris · 词条样板视觉依据

核对日期：2026-09-18。来源为用户指定仓库 main 分支的公开源文件，非线上站点截图。

- app/globals.css：纸面 #F7F3E8，表面 #FCFAF3，正文 #171A15，次级文字 #686E64，细线 #DAD8CD。
- 默认 moss：#52683F / #35472A，浅色底 #E9EEDB，北极星 #AFC82E。
- 保留 indigo、clay、pine、plum 五主题，以及 paper、oat、limestone、pearl、mist 五纸色。
- dark 独立预设：#191C18 / #222720，正文 #EEEBDD，accent #B6CC32。
- 中文系统无衬线正文；代码等宽。原站没有外载品牌字体，不在交付中附任何字体文件。
- SiteHeader.tsx：文字 VibePolaris / Vibe指北，术语、选型指南、工具、关于，64px 顶栏。
- app/terms/[slug]/page.tsx：现有 dedicatedTermPages["agent-harness"]。不建议另建 /harness 路由。
- AgentHarnessTermPage.module.css：中等圆角、细分割线、短导语、居中阅读区。
- BrandMark.tsx + globals.css 使用原站 PNG 蒙版。本环境未取得 PNG 字节，离线预览仅用文字品牌，不伪造图形 Logo；接入网站时复用现有 SiteHeader 与 BrandMark。

资料：
https://github.com/Gyschuaner/VibePolaris
https://raw.githubusercontent.com/Gyschuaner/VibePolaris/main/app/globals.css
https://raw.githubusercontent.com/Gyschuaner/VibePolaris/main/components/SiteHeader.tsx
https://raw.githubusercontent.com/Gyschuaner/VibePolaris/main/components/terms/AgentHarnessTermPage.tsx

原则：复用学习节奏、设计变量、无障碍与控件；不强制所有概念使用同一张循环图。主题变更不影响内容与模拟状态。
