# VibePolaris · Harness 词条样板

这是对现有网站风格与 `/terms/agent-harness` 入口的设计深化，不是另一套课程官网。

## 先看效果

直接使用浏览器打开 `harness-vibepolaris.html`。HTML 内联了样式、交互与教学数据，不需要 npm、模型 Key 或在线服务。导航和原始资料链接会访问外部网站，但实验本身完全在本地运行。

页面默认不自动播放。点击“下一步”，或切换到“只用模型”，观察同一个任务在不同能力条件下的差异。实验包含成功、文件不存在、权限拒绝三种结果；右侧可以切换“这一步 / 上下文 / 轨迹”。

## 文件组织

- `harness-vibepolaris.html`：可直接打开的完整预览。
- `src/page.html`：教学内容与页面结构；不是 React JSX。
- `src/theme.css`：复现原站已公开的语义主题变量，仅供独立预览。
- `src/concept.css`：词条排版、交互面板与响应式样式。
- `src/lesson-core.js`：无副作用的教学状态机；不访问真实模型或文件。
- `src/interaction.js`：浏览器控制器，拥有自己的事件监听器、计时器与清理函数。
- `template/ConceptPage.types.ts`：后续词条的框架无关 TypeScript 内容契约。
- `template/harness.definition.ts`：首个词条的配置示例；用于未来 React 迁移，不是当前 HTML 的自动渲染入口。
- `TEMPLATE.md`：哪些部分统一、哪些部分为每个知识点定制。
- `INTEGRATION.md`：与现有 VibePolaris 源码的映射和接入边界。
- `design/`：已确认方向、真实配色依据与交互分镜。
- `tests/`：状态机测试、浏览器交互测试和报告。

## 编辑与重建

编辑 `src` 后，在该目录执行：

```bash
python3 build.py
node --test tests/lesson-core.test.cjs
```

构建脚本只用 Python 标准库；状态机测试只用 Node 标准库。不会自动下载依赖。

可选浏览器检查（需要自行已有 Playwright 和 Chromium）：

```bash
CHROMIUM_PATH=/usr/bin/chromium python3 tests/browser.test.py
```

## 已检查与未检查

已通过 16 项纯状态机测试、35 项浏览器交互检查；人工查看了桌面、窄屏和夜间主题的实际渲染。320 / 390 / 768 / 1024 / 1440 像素宽度未检测到整页横向溢出。检查覆盖单步、自动播放与暂停、上下文出现时机、两种错误、弹窗、主题切换、测验和减少动态效果。

受本次运行环境导航限制，浏览器测试通过 Playwright `set_content` 加载本地 HTML 字节，而非访问已部署网址。没有运行完整 VibePolaris 项目的构建与回归，没有测试 localStorage 在浏览器重启后的持久化，也没有验证真实模型/文件/CAD 操作。

没有向 GitHub 提交、创建 PR 或部署。交付的是可交互设计原型与可编辑源码，不是声称已完成生产迁移的补丁。

## 视觉与品牌边界

纸面色、苔藓绿、其余主题色和固定夜间配色来自原站 `app/globals.css`。独立预览使用文字品牌，未重新绘制原站流星/北极星图形，也没有打包任何字体。生产接入请直接使用现有 `SiteHeader`、`BrandMark`、`ThemeStudio`、`SiteFooter`，不要复制预览顶栏。

源码依据见 `design/brand-spec.md`；知识来源也可在网页底部“参考与进一步阅读”中打开。
