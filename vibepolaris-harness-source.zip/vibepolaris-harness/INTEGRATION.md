# 接入现有 VibePolaris

## 已核对的现状

公开 `main` 分支中已经存在：

- `app/terms/[slug]/page.tsx`：`dedicatedTermPages` 已将 `agent-harness` 映射至 `AgentHarnessTermPage`。
- `components/terms/AgentHarnessTermPage.tsx`：专属 Harness 词条页。
- `components/terms/HarnessLesson.tsx` 及其 CSS Module：现有交互课程。
- `lib/harness-lesson`：现有实验所使用的数据/状态逻辑。
- `components/terms/BespokeTermScaffold.tsx`：包含 `BespokeTermPageProps` 等公共约定。
- `components/SiteHeader.tsx`、`BrandMark`、`ThemeStudio`、`SiteFooter` 和 `app/globals.css`：应保留的母站能力。

本地原型没有修改这些文件。下面是迁移方案，而不是已经应用的改动清单。

## 迁移顺序

### 1. 不增加重复入口

继续沿用 `/terms/agent-harness` 与已注册的 `dedicatedTermPages`，不要另建 `/harness` 落地页。保留词条 metadata、内容模型、`previous / next / related`、静态生成与校验逻辑。

### 2. 保留原站外壳

不要复制 `page.html` 里的预览 header/footer，也不要导入独立预览 `theme.css`。原站已经负责主题初始化、字体栈、品牌图形与站内导航。

本原型 CSS 顶部有为独立页面设置的 `html/body/button/a` 基础规则。接入时这些规则应删除或局部化，其余 `vp-` 样式迁移成 CSS Module；不能整文件直接挂到全局。

### 3. 分开服务端内容和客户端实验

`AgentHarnessTermPage` 保留词条标题、定义、章节正文、相关链接与参考资料，优先由服务端渲染。

实验、弹窗、可切换解释、测验拆成客户端组件。现有 `HarnessLesson` 是最自然的实验升级位置；通过 React 状态声明渲染 DOM，而不是在 React 管理的节点里直接运行预览控制器。

推荐的依赖关系：

```text
AgentHarnessTermPage（现有页面）
 ├─ ConceptHeader / ConceptSection / RelatedConcepts（逐步提取共享）
 ├─ HarnessLesson（客户端、Harness 专属拓扑）
 │   ├─ lesson reducer / frame selectors（无副作用）
 │   ├─ StepControls（通用）
 │   ├─ LessonInspector（通用容器；各词条自带数据）
 │   └─ HarnessDiagram（专属模型—运行层—工具图）
 ├─ ConceptGlossary（通用轻解释）
 └─ KnowledgeCheck（通用交互）
```

先对照现有实现复用能力，再新增组件，避免保留两套重复状态机。

### 4. 把新教学行为迁入现有状态逻辑

参考 `src/lesson-core.js` 中 `createState / reduce / frame` 的职责，但应融入现有 TypeScript 文件及现有测试，不要用第二份 UMD 全局对象覆盖它。

React 中状态可采用：

```tsx
const [state, dispatch] = useReducer(reducer, initialState);
const view = selectFrame(state);
```

计时器放入 effect，返回清理函数；用户手动换步骤、改场景、离开实验视口或隐藏页面时暂停。SVG 连线由 ResizeObserver 和实际元素边界计算；采用 React `useId()` 生成 marker / dialog / tab IDs，防止多个实验在同一页面冲突。

本原型使用的是单页固定 ID，因此不能把多个原型片段直接插到同一个 DOM 中。

### 5. 保留这些语义不变量

- 模型提出请求后，文件内容仍然未知。
- 工具被调度，与结果已经返回，是两个不同阶段。
- 权限拒绝场景的工具执行次数始终为零。
- 文件不存在场景不能渲染成功内容。
- 错误记录也可进入后续模型输入。
- 输出回答、等待补充、等待授权都可以结束一轮，但不是同一种任务结果。
- 本页面是确定性教学模拟，不得用真实服务凭证替换成线上操作。

### 6. 原站相关词条与数据模型

预览中已知页面使用 `/terms/context`、`/terms/agent` 等链接；不确定 slug 的项目采用站内查询。正式接入应从 `related` 数据解析真实 slug，不要把独立预览中的站点绝对 URL 原样保留。

`template/*.ts` 是建议的内容契约，不取代已有 Zod schema。应先与现有 `Term` 数据模型对齐，再决定哪些字段值得复用；不要为了这一个页面重写全站内容层。

### 7. 验收

在获得完整仓库及依赖后，运行原站的 `typecheck / lint / test / build` 或既有 `check` 脚本，并检查现有词条未回归。本次仅验证了交付原型和所附纯状态机，不代表原站构建已经通过。

生产还应验证：路由跳转后计时器清理、系统主题恢复、浏览器前后导航、服务端/客户端 hydration 一致性、品牌蒙版素材、键盘焦点、触摸目标和实际手机阅读。

## 原始源码地址

- https://github.com/Gyschuaner/VibePolaris
- https://raw.githubusercontent.com/Gyschuaner/VibePolaris/main/app/terms/%5Bslug%5D/page.tsx
- https://raw.githubusercontent.com/Gyschuaner/VibePolaris/main/components/terms/AgentHarnessTermPage.tsx
- https://raw.githubusercontent.com/Gyschuaner/VibePolaris/main/components/terms/HarnessLesson.tsx
- https://raw.githubusercontent.com/Gyschuaner/VibePolaris/main/app/globals.css

源码观察日期：2026-09-18。迁移前应重新检查仓库变更。
